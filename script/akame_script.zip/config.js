/*
     *Base : Fallzx
     *Creator : KyyXD
     *Created On : 19/3/25
     *Whatsapp : 6288286624778
     *Chanel Yt : @KyyHost
     
     JANGAN JUAL MEMEK,, RECODE? JANGAN HAPUS CREDITNYA ANJINK 
     CREATED : KYYXD
     CH RESMI : https://whatsapp.com/channel/0029Vb7gTNO5a2450z5MnD0k
*/


//==============[ SETT BOT ]================\\
global.botname = ["ᴀᴋᴀᴍᴇ - ᴀɪ"] 
global.botnumber = ["6288286624778"] 
global.packname = 'Stick By'
global.author = 'Kyy\nAkame'
global.versionInfo = '10.0.0'
//===========================================\\

//=============[ SETT OWNER ]==================\\
global.owner = [ "6288286624778", ] 
global.ownername = "ᴋʏʏxᴅᴢ" 
global.website = "https://akameky.netlify.app/"
global.yt = "https://www.youtube.com/@KyyHost"
//===========================================\\

//============[ GROUP AND SALURAN ]========\\
global.linkgc = '-'
global.linknya = 'https://whatsapp.com/channel/0029Vb7gTNO5a2450z5MnD0k'
global.idch = ['120363405649403674@newsletter'] 
global.newsletername = "ᴀᴋᴀᴍᴇ ɴᴇᴡ ʙʏ ᴋʏy"
//===========================================\\

//============[ PAYMENT ]=============\\
global.dana = '088286624778'
global.ovo = '' 
global.gopay = ''
//===========================================\\

//=============[ SETTINGS ]===============\\
global.welcome = true
global.onlygc = false
global.autoread = true
global.autotyping = true
global.self = false
global.autoJamAktif = false
global.public = true
global.wlcm = []
global.wlcmm = []
//===========================================\\ 

//============[ FUNCTION LAIN NYA ]========\\
global.fotonya2 = "https://img12.pixhost.to/images/1030/577700311_kyyxd.jpg"
global.warn = "https://img12.pixhost.to/images/1490/584818417_6726.jpg"
global.websitex = ['-']
global.qris = "https://img12.pixhost.to/images/1036/577757623_kyyxd.jpg"
global.apilinode = '75a4103e2105b1bf8913542f88ef1de75e7bf93469fe131e39a4f840878e45ef'
global.wlcm = []
global.wlcmm = []
global.limitawal = {
    premium: "Infinity",
    free: 30
}

global.egg = "15"
global.nestid = "5"
global.loc = "1"
global.domain = "-"//domain
global.apikey = "-"//plta
global.capikey = "-"//pltc
//===========================================\\

//===================[ MESS ]=====================\\
global.mess = {
    success: '𝙳𝚘𝚗𝚎 𝙺𝚊𝚔 ',
    admin: '[ !! ] ᴋʜᴜsᴜs ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ',
    botAdmin: '[ !! ] ᴀᴋᴀᴍᴇ ʙᴇʟᴜᴍ ᴊᴀᴅɪ ᴀᴅᴍɪɴ',
    OnlyOwner: '[ !! ] ғᴇᴀᴛᴜʀᴇ ɪɴɪ ᴋʜᴜsᴜs ᴋʏʏ ᴅᴏᴀɴᴋ',
    OnlyGrup: '[ !! ] ғᴇᴀᴛᴜʀᴇ ɪɴᴜ ᴋʜᴜsᴜs ɢʀᴏᴜᴘ ᴀᴊᴀ',
    private: '[ !! ] ғᴇᴀᴛᴜʀᴇ ᴋʜᴜsᴜs ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ ᴀᴋᴀᴍᴇ',
    wait: '[ !! ] ᴡᴀɪᴛ ᴀᴋᴀᴍᴇ ᴘʀᴏsᴇs ᴅᴜʟᴜ',
    notregist: '[ !! ]\nᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴛᴇʀᴅᴀғᴛᴀʀ ᴅɪ ᴀᴋᴀᴍᴇ sɪʟᴀʜᴋᴀɴ ᴅᴀғᴛᴀʀ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ .ᴅᴀғᴛᴀʀ',
    premium: '[ !! ] ғᴇᴀᴛᴜʀᴇ ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ ᴀᴋᴀᴍᴇ',
    endLimit: '[ !! ] ʟɪᴍɪᴛ ᴀɴᴅᴀ ʜᴀʙɪs ,, ᴀᴋᴀɴ ᴅɪ ʀᴇsᴇᴛ sᴇᴛᴇʟᴀʜ sᴇʜᴀʀɪ',
}

global.rpg = {
emoticon(string) {
string = string.toLowerCase()
let emot = {
level: '📊',
limit: '🎫',
health: '❤️',
exp: '✨',
atm: '💳',
money: '💰',
bank: '🏦',
potion: '🥤',
diamond: '💎',
common: '📦',
uncommon: '🛍️',
mythic: '🎁',
legendary: '🗃️',
superior: '💼',
pet: '🔖',
trash: '🗑',
armor: '🥼',
sword: '⚔️',
pickaxe: '⛏️',
fishingrod: '🎣',
wood: '🪵',
rock: '🪨',
string: '🕸️',
horse: '🐴',
cat: '🐱',
dog: '🐶',
fox: '🦊',
robo: '🤖',
petfood: '🍖',
iron: '⛓️',
gold: '🪙',
emerald: '❇️',
upgrader: '🧰',
bibitanggur: '🌱',
bibitjeruk: '🌿',
bibitapel: '☘️',
bibitmangga: '🍀',
bibitpisang: '🌴',
anggur: '🍇',
jeruk: '🍊',
apel: '🍎',
mangga: '🥭',
pisang: '🍌',
botol: '🍾',
kardus: '📦',
kaleng: '🏮',
plastik: '📜',
gelas: '🧋',
chip: '♋',
umpan: '🪱',
skata: '🧩'
}
let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
if (!results.length) return ''
else return emot[results[0][0]]
}
}

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})