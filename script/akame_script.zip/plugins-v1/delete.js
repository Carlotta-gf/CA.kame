let handler = async (m, { Kyyhst, isCreator, example, Reply }) => {
  if (m.isGroup) {
    if (!isCreator && !m.isAdmin) return reply(mess.admin);
    if (!m.quoted) return m.reply("reply pesannya");
    if (m.quoted.fromMe) {
      Kyyhst.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: true,
          id: m.quoted.id,
          participant: m.quoted.sender,
        },
      });
    } else {
      if (!isBotAdmin) return reply(mess.botAdmin);
      Kyyhst.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.quoted.id,
          participant: m.quoted.sender,
        },
      });
    }
  } else {
    if (!isCreator) return reply(mess.owner);
    if (!m.quoted) return m.reply(example("reply pesan"));
    Kyyhst.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: m.quoted.id,
        participant: m.quoted.sender,
      },
    });
  }
};

handler.command = ["delete", "del"];

module.exports = handler;
