const fs = require('fs');

module.exports = {
    command: ['ownermenu'],
    operate: async ({ Kyyhst, m }) => {
        let teks = `Owner Menu\n`;
        teks += `\n`;
        teks += `─ sᴇʟғ\n`;
        teks += `─ ᴘᴜʙʟɪᴄ\n`;
        teks += `─ ɢᴇᴛᴄᴀsᴇ\n`;
        teks += `─ ᴀᴅᴅᴄᴀsᴇ\n`;
        teks += `─ ᴇᴅɪᴛᴄᴀsᴇ\n`;
        teks += `─ ᴀᴅᴅᴘʀᴇᴍ\n`;
        teks += `─ ᴅᴇʟᴘʀᴇᴍ\n`;
        teks += `─ ᴀᴅᴅᴘʟᴜɢɪɴs\n`;
        teks += `─ ᴅᴇʟᴘʟᴜɢɪɴs\n`;
        teks += `─ ɢᴇᴛᴘʟᴜɢɪɴs\n`;
        teks += `─ ʟɪsᴛᴘʟᴜɢs\n`;
        teks += `─ sᴀᴠᴇᴘʟᴜɢɪɴs\n`;
        teks += `─ ʟᴇᴍᴏɴᴍᴀɪʟ\n`;
        teks += `─ ᴊᴏɪɴ\n`;
        teks += `─ ʟᴇᴀᴠᴇ\n`;
        teks += `─ ᴄʜᴀᴛ\n`;
        teks += `─ ᴜᴘᴄʜ\n`;
        teks += `─ ʀᴇᴀᴄᴛᴄʜ\n`;
        teks += `─ ʙᴄɢᴄ\n`;
        teks += `─ ʙᴀᴄᴋᴜᴘ\n`;
        teks += `─ ʙᴘᴛᴀɢ\n`;
        teks += `─ ᴀᴍʙɪʟᴄᴏᴅᴇ\n`;
        teks += `─ ɢᴇᴛғɪʟᴇ\n`;
        teks += `─ sᴇᴛғɪʟᴇ\n`;
        teks += `─ ɴᴏᴇɴᴄ\n`;
        teks += `─ sᴇᴛᴄᴏᴅᴇ\n`;
        teks += `─ ᴊᴀᴛᴜʜᴋᴀɴᴅʀᴏᴘ\n`;
        teks += `─ ʟɪsᴛʀᴇᴅᴇᴇᴍ\n`;
        teks += `─ ʜᴀᴘᴜsʀᴇᴅᴇᴇᴍ\n`;
        teks += `─ ʟɪsᴛғɪx\n`;
        teks += `─ ᴀᴅᴅғɪx\n`;
        teks += `─ ᴀɴᴛɪᴛᴀɢsᴡ\n`;
        teks += `─ ᴀᴜᴛᴏᴅᴇʟ𝟸𝟺ᴊᴀᴍ\n`;
        teks += `─ ᴄᴇᴋɪᴅɢᴄ\n`;
        teks += `─ ᴄᴜʟɪᴋᴀᴍᴀɴ\n`;
        teks += `─ ʟɪsᴛɢʀᴏᴜᴘ\n`;

        await Kyyhst.sendMessage(m.chat, {
            image: { url: 'https://i.supa.codes/6ZHKuH' }, // atau pakai buffer fs.readFileSync('path')
            caption: teks
        }, { quoted: m });
    }
};
