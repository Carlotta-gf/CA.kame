module.exports = {
    command: ['groupmenu'],
    operate: async ({ Kyyhst, m }) => {
        let teks = `Group Menu\n\n`;
        teks += `─ ᴀɴᴛɪᴘʀᴏᴍᴏᴛɪᴏɴ\n`;
        teks += `─ ᴀɴᴛɪᴡᴀᴍᴇ\n`;
        teks += `─ ᴀɴᴛɪᴀꜱɪɴɢ\n`;
        teks += `─ ᴀɴᴛɪᴠɪʀᴛᴇx\n`;
        teks += `─ ᴀɴᴛɪʟɪɴᴋᴀʟʟ\n`;
        teks += `─ ᴀɴᴛɪʟɪɴᴋꜰʙ\n`;
        teks += `─ ᴀɴᴛɪʟɪɴᴋᴛɪᴋᴛᴏᴋ\n`;
        teks += `─ ᴀɴᴛɪʟɪɴᴋʏᴛ\n`;
        teks += `─ ᴀɴᴛɪʟɪɴᴋʏᴛᴄʜ\n`;
        teks += `─ ᴀɴᴛɪʟɪɴᴋɪɢ\n`;
        teks += `─ ᴀɴᴛɪʟɪɴᴋᴛᴇʟᴇ\n`;
        teks += `─ ᴀɴᴛɪᴅᴇᴡᴀsᴀ\n`;
        teks += `─ ᴀɴᴛɪʟɪɴᴋᴛᴡɪᴛᴛᴇʀ\n`;
        teks += `─ ᴀɴᴛɪʟɪɴᴋɢᴄ\n`;
        teks += `─ ᴋɪᴄᴋ\n`;
        teks += `─ ʜɪᴅᴇᴛᴀɢ\n`;
        teks += `─ ᴛᴀɢᴀʟʟ\n`;
        teks += `─ ᴛᴏᴛᴀɢ\n`;
        teks += `─ ᴏᴘᴇɴ\n`;
        teks += `─ ᴏᴘᴇɴᴛɪᴍᴇ\n`;
        teks += `─ ᴄʟᴏꜱᴇ\n`;
        teks += `─ ᴄʟᴏꜱᴇᴛɪᴍᴇ\n`;
        teks += `─ ᴘʀᴏᴍᴏᴛᴇ\n`;
        teks += `─ ᴅᴇᴍᴏᴛᴇ\n`;
        teks += `─ ꜱᴇᴛɴᴀᴍᴇ\n`;
        teks += `─ ꜱᴇᴛᴅᴇꜱᴄ\n`;
        teks += `─ ʟɪɴᴋɢᴄ\n`;
        teks += `─ ʀᴇᴠᴏᴋᴇ\n`;
        teks += `─ ᴛᴏᴛᴀʟᴀᴅᴍɪɴ\n`;
        teks += `─ ᴛᴏᴛᴀʟᴍᴇᴍʙᴇʀ\n`;
        teks += `─ ᴀɴᴛɪʟɪɴᴋɢᴄ\n`;
        teks += `─ ᴀɴᴛɪᴛᴀɢsᴡ\n`;

        await Kyyhst.sendMessage(m.chat, {
            image: { url: 'https://i.supa.codes/6ZHKuH' },
            caption: teks
        }, { quoted: m });
    }
};
