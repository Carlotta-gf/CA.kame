const fs = require('fs');

module.exports = {
    command: ['rpgmenu'],
    operate: async ({ Kyyhst, m }) => {
        let teks = `Owner Menu\n\n`;
        teks += `─ ᴍʏɢᴜɪʟᴅ\n`;
        teks += `─ ɢᴜɪʟᴅɪɴꜰᴏ\n`;
        teks += `─ ᴅᴇʟɢᴜɪʟᴅ\n`;
        teks += `─ ᴊᴏɪɴɢᴜɪʟᴅ\n`;
        teks += `─ ᴄʀᴇᴀᴛᴇɢᴜɪʟᴅ\n`;
        teks += `─ ʟɪꜱᴛɢᴜɪʟᴅ\n`;
        teks += `─ ᴋᴇʀᴊᴀ\n`;
        teks += `─ ʙᴀɴᴋᴄᴇᴋ\n`;
        teks += `─ ᴍᴀʟɪɴɢ\n`;
        teks += `─ ʙᴀɴᴋɴᴀʙᴜɴɢ\n`;
        teks += `─ ʙᴀɴᴋᴛᴀʀɪᴋ\n`;
        teks += `─ ʙᴇʀᴋᴇʙᴏɴ\n`;
        teks += `─ ᴄʀᴀꜰᴛɪɴɢ\n`;
        teks += `─ ʙᴇᴛ\n`;
        teks += `─ ʙᴏɴᴜꜱ\n`;
        teks += `─ ʙᴜᴀʜ\n`;
        teks += `─ ɴᴇʙᴀɴɢ\n`;
        teks += `─ ʙᴇᴋᴇʀᴊᴀ\n`;
        teks += `─ ʙᴀɴꜱᴏꜱ\n`;
        teks += `─ ᴛᴀxʏ\n`;
        teks += `─ ᴍᴜʟᴜɴɢ\n`;
        teks += `─ ʙᴇʀʙᴜʀᴜ\n`;
        teks += `─ ᴘᴏʟɪꜱɪ\n`;
        teks += `─ ʙᴇʀᴅᴀɢᴀɴɢ\n`;
        teks += `─ ʀᴀᴍᴘᴏᴋ\n`;
        teks += `─ ʙᴜɴᴜʜ\n`;
        teks += `─ ᴄᴏʟʟᴇᴄᴛ\n`;
        teks += `─ ᴍᴀɴᴄɪɴɢ\n`;
        teks += `─ ʀᴇᴘᴀɪʀ\n`;
        teks += `─ ꜰᴇᴇᴅ\n`;
        teks += `─ ꜰɪɢʜᴛ\n`;
        teks += `─ ɢᴀᴊɪᴀɴ\n`;
        teks += `─ ᴜᴘɢʀᴀᴅᴇ\n`;
        teks += `─ ᴛʀᴀɴꜱꜰᴇʀ\n`;
        teks += `─ ꜱʜᴏᴘ\n`;
        teks += `─ ꜱᴇʟᴇᴄᴛꜱᴋɪʟʟ\n`;
        teks += `─ ꜱᴀᴍᴘᴀʜ\n`;
        teks += `─ ʀᴏᴋᴇᴛ\n`;
        teks += `─ ᴏᴊᴇᴋ\n`;
        teks += `─ ɴɢᴜʟɪ\n`;
        teks += `─ ᴘᴀꜱᴀʀ\n`;
        teks += `─ ʀᴏʙ\n`;
        teks += `─ ʀᴇꜰᴇʀᴀʟ\n`;
        teks += `─ ᴘᴇᴛꜱʜᴏᴘ\n`;
        teks += `─ ᴋᴏʟᴀᴍ\n`;
        teks += `─ ᴋᴏʙᴏʏ\n`;
        teks += `─ ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ\n`;

        await Kyyhst.sendMessage(m.chat, {
            image: { url: 'https://i.supa.codes/6ZHKuH' }, // bisa diganti pakai buffer
            caption: teks
        }, { quoted: m });
    }
};
