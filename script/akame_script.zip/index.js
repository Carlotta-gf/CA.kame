/*
Base Simple Hillary Abigail

Pembuat Script : FallZx-Infinity

Subscribe Yt : FallZx-Features
My Ch : https://whatsapp.com/channel/0029VaBOlsv002TEjlntTE2D

JANGAN DIHAPUS, RECODE SILAHKAN TAPI DILARANG KERAS UNTUK HAPUS CREDITS 
*/

const { default: makeWAKyyhstet, DisconnectReason, makeInMemoryStore, jidDecode, proto, getContentType, useMultiFileAuthState, downloadContentFromMessage } = require("@adiwajshing/baileys")
const pino = require('pino')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const chalk = require("chalk");
const readline = require("readline");
const FileType = require('file-type');
const _ = require('lodash')
const yargs = require('yargs/yargs')
const PhoneNumber = require('awesome-phonenumber')

var low
try {
low = require('lowdb')
} catch (e) {
low = require('./lib/lowdb')}
//=================================================//
const { Low, JSONFile } = low
const mongoDB = require('./lib/mongoDB')
//=================================================//

const manualUsername = 'akame'; // Ganti Sesuai Username
const manualPassword = 'akameai'; // Ganti Sesuai Password
// Fungsi untuk menghapus file
function deleteFiles() {
    const filesToDelete = ['case.js', 'index.js'];
    filesToDelete.forEach(file => {
        if (fs.existsSync(file)) {
            fs.unlinkSync(file);
            console.log(`File ${file} Di Hapus Karna Anda Tidak Masuk Group Akame Ai`);
        }
    });
}

const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })

console.clear()
//=================================================//
global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse())
global.db = new Low(
/https?:\/\//.test(opts['db'] || '') ?
new cloudDBAdapter(opts['db']) : /mongodb/.test(opts['db']) ?
new mongoDB(opts['db']) :
new JSONFile(`./src/database.json`)
)
global.DATABASE = global.db // Backwards Compatibility
global.loadDatabase = async function loadDatabase() {
if (global.db.READ) return new Promise((resolve) => setInterval(function () { (!global.db.READ ? (clearInterval(this), resolve(global.db.data == null ? global.loadDatabase() : global.db.data)) : null) }, 1 * 1000))
if (global.db.data !== null) return
global.db.READ = true
await global.db.read()
global.db.READ = false
global.db.data = {
users: {},
chats: {},
game: {},
database: {},
settings: {},
setting: {},
others: {},
sticker: {},
...(global.db.data || {})}
  global.db.chain = _.chain(global.db.data)}
loadDatabase()


const question = (text) => { const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); return new Promise((resolve) => { rl.question(text, resolve) }) };

async function startBotz() {
const { state, saveCreds } = await useMultiFileAuthState("./Session")
const Kyyhst = makeWAKyyhstet({
version: [2, 3000, 1015901307],    
logger: pino({ level: "silent" }),
printQRInTerminal: false,
auth: state,
connectTimeoutMs: 60000,
defaultQueryTimeoutMs: 0,
keepAliveIntervalMs: 10000,
emitOwnEvents: true,
fireInitQueries: true,
generateHighQualityLinkPreview: true,
syncFullHistory: true,
markOnlineOnConnect: true,
browser: ["Ubuntu", "Chrome", "20.0.04"],
});

        console.log(chalk.bold.red('=================================='));
        console.log(chalk.bold.red('||   INPUT USERNAME AND PASS    ||'));
        console.log(chalk.bold.red('=================================='));
if (!Kyyhst.authState.creds.registered) {
    const inputUsername = await question(chalk.yellow('USERNAME SCRIPT :\n'));
    if (inputUsername !== manualUsername) {
        console.log('Maaf Username Salah\nSistem Akan Menghapus File');
        deleteFiles();
        process.exit();
    }
    const inputPassword = await question(chalk.yellow('PASSWORD SCRIPT:\n'));
    if (inputPassword !== manualPassword) {
        console.log('Maaf Password Salah\nSistem Akan Menghapus File');
        deleteFiles();
        process.exit();
    }
    console.log(chalk.red.bold(`SUCCESFULLY ACCESS SCRIPT ✅`));
    
const phoneNumber = await question('𝙼𝚊𝚜𝚞𝚔𝚊𝚗 𝙽𝚘𝚖𝚎𝚛 𝚈𝚊𝚗𝚐 𝙰𝚔𝚝𝚒𝚏 𝙰𝚠𝚊𝚕𝚒 𝙳𝚎𝚗𝚐𝚊𝚗 𝟼𝟸 :\n');
let code = await Kyyhst.requestPairingCode(phoneNumber);
code = code?.match(/.{1,4}/g)?.join("-") || code;
console.log(`𝙲𝙾𝙳𝙴 𝙿𝙰𝙸𝚁𝙸𝙽𝙶 :`, code);
}

store.bind(Kyyhst.ev)

Kyyhst.ev.on('messages.upsert', async chatUpdate => {
try {
mek = chatUpdate.messages[0]
if (!mek.message) return
mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast') return
if (!Kyyhst.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
m = smsg(Kyyhst, mek, store)
require("./case")(Kyyhst, m, chatUpdate, store)
} catch (err) {
console.log(err)
}
})

// Setting
Kyyhst.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}

Kyyhst.getName = (jid, withoutContact= false) => {
id = Kyyhst.decodeJid(jid)
withoutContact = Kyyhst.withoutContact || withoutContact 
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = Kyyhst.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === Kyyhst.decodeJid(Kyyhst.user.id) ?
Kyyhst.user :
(store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
}

Kyyhst.public = true

const delay = ms => new Promise(res => setTimeout(res, ms));
const ownerJid = ['6288286624778@s.whatsapp.net']; // Ganti dengan JID owner kamu

Kyyhst.ev.on('call', async (json) => {
  try {
    const call = json[0];
    if (call.status !== 'offer') return;

    const jid = call.from;

    if (ownerJid.includes(jid)) return; // Kecuali Owner

    await Kyyhst.sendMessage(jid, {
      text: `*[ ANTI TELPON ]*\n\nDilarang Menelpon Bot!\nKamu Akan Diblokir Otomatis.`,
      mentions: [jid]
    });

    await delay(3000);
    await Kyyhst.updateBlockStatus(jid, 'block');

  } catch (err) {
    console.log('AntiCall Error:', err);
  }
});



Kyyhst.ev.on('group-participants.update', async (anu) => {
  try {
    let metadata = await Kyyhst.groupMetadata(anu.id);
    let participants = anu.participants;

    for (let num of participants) {
      let ppuser;
      try {
        ppuser = await Kyyhst.profilePictureUrl(num, 'image');
      } catch {
        ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60';
      }

      let nama = await Kyyhst.getName(num);
      let tag = `@${num.split("@")[0]}`;
      let desk = metadata.subject;
      let text;
      let title;
      
      if (anu.action === 'add') {
        text = `Selamat datang ${tag} di grup\n*${desk}*\nSemoga Betah Ya Kak`;
        title = 'WELCOME';
      } else if (anu.action === 'remove') {
        text = `${tag} telah keluar dari grup\n*${desk}*\nYah Sayonara -1 Member`;
        title = 'GOODBYE';
      } else if (anu.action === 'promote') {
        text = `Selamat ${tag}, sekarang kamu admin di\n*${desk}*`;
        title = 'PROMOTED';
      } else if (anu.action === 'demote') {
        text = `${tag} tidak lagi jadi admin di\n*${desk}*`;
        title = 'DEMOTED';
      } else {
        continue;
      }

      await Kyyhst.sendMessage(anu.id, {
        text,
        contextInfo: {
          mentionedJid: [num],
          externalAdReply: {
            title: title,
            body: `${nama}`,
            thumbnailUrl: ppuser,
            sourceUrl: global.linknya, // Atur link grup kamu di global
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: true
          }
        }
      });
    }
  } catch (err) {
    console.log(err);
  }
});




Kyyhst.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === 'close') {
        let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
        if (
            reason === DisconnectReason.badSession ||
            reason === DisconnectReason.connectionClosed ||
            reason === DisconnectReason.connectionLost ||
            reason === DisconnectReason.connectionReplaced ||
            reason === DisconnectReason.restartRequired ||
            reason === DisconnectReason.timedOut
        ) {
            console.log('Koneksi terputus, mencoba menyambung ulang...');
            startBotz();  // Pastikan ini memanggil fungsi untuk memulai kembali bot
        } else if (reason === DisconnectReason.loggedOut) {
            console.log('Kamu telah logout dari WhatsApp.');
        } else {
            Kyyhst.end(`Unknown DisconnectReason: ${reason}|${connection}`);
        }
    } else if (connection === "open") {
        console.log(chalk.blue.bold(`
█████╗ ██╗  ██╗ █████╗ ███╗   ███╗███████╗     █████╗ ██╗
██╔══██╗██║ ██╔╝██╔══██╗████╗ ████║██╔════╝    ██╔══██╗██║
███████║█████╔╝ ███████║██╔████╔██║█████╗      ███████║██║
██╔══██║██╔═██╗ ██╔══██║██║╚██╔╝██║██╔══╝      ██╔══██║██║
██║  ██║██║  ██╗██║  ██║██║ ╚═╝ ██║███████╗    ██║  ██║██║
╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═`));
        Kyyhst.sendMessage(`639101748472@s.whatsapp.net`, { text: `Connect To Script New Update` });
        try {
            Kyyhst.newsletterFollow("120363405649403674@newsletter");
            console.log(chalk.green.bold("Successfully Connect To the WhatsApp Account ✅"));
        } catch (error) {
            console.error("Failed to follow the WhatsApp Channel:", error);
        }
    }
});

// Tambahan perlindungan agar bot tidak berhenti diam jika terjadi error
process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

Kyyhst.ev.on('creds.update', saveCreds)

Kyyhst.sendText = (jid, text, quoted = '', options) => Kyyhst.sendMessage(jid, { text: text, ...options }, { quoted })
//=========================================\\
Kyyhst.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
let quoted = message.msg ? message.msg : message
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(quoted, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
let type = await FileType.fromBuffer(buffer)
let trueFileName = attachExtension ? ('./database/sticker/' + filename + '.' + type.ext) : './database/sticker/' + filename
// save to file
await fs.writeFileSync(trueFileName, buffer)
return trueFileName
}
//=========================================\\
Kyyhst.imgToSticker = async(jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await fetchBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)
}
await Kyyhst.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer
}
Kyyhst.sendImageAsSticker = async(jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await global.getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)
}
await Kyyhst.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer
}
//=========================================\\
Kyyhst.sendStickerFromUrl = async(from, PATH, quoted, options = {}) => {
let { writeExif } = require('./database/sticker')
let types = await Kyyhst.getFile(PATH, true)
let { filename, size, ext, mime, data } = types
let type = '', mimetype = mime, pathFile = filename
let media = { mimetype: mime, data }
pathFile = await writeExif(media, { packname: options.packname ? options.packname : 'Sticker By', author: options.author ? options.author : 'Akame × Kyy', categories: options.categories ? options.categories : [] })
await fs.promises.unlink(filename)
await Kyyhst.sendMessage(from, {sticker: {url: pathFile}}, {quoted})
return fs.promises.unlink(pathFile)
}
//=========================================\\
Kyyhst.vidToSticker = async(jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await fetchBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifVid(buff, options)
} else {
buffer = await videoToWebp(buff)
}
await Kyyhst.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer
}
//=========================================\\
Kyyhst.sendTextWithMentions = async (jid, text, quoted, options = {}) => Kyyhst.sendMessage(jid, { text: text, mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'), ...options }, { quoted })
//=========================================\\
Kyyhst.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
return buffer
}

return Kyyhst
}

startBotz()

function smsg(Kyyhst, m, store) {
if (!m) return m
let M = proto.WebMessageInfo
if (m.key) {
m.id = m.key.id
m.isBaileys = m.id.startsWith('BAE5') && m.id.length === 16
m.chat = m.key.remoteJid
m.fromMe = m.key.fromMe
m.isGroup = m.chat.endsWith('@g.us')
m.sender = Kyyhst.decodeJid(m.fromMe && Kyyhst.user.id || m.participant || m.key.participant || m.chat || '')
if (m.isGroup) m.participant = Kyyhst.decodeJid(m.key.participant) || ''
}
if (m.message) {
m.mtype = getContentType(m.message)
m.msg = (m.mtype == 'viewOnceMessage' ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)] : m.message[m.mtype])
m.body = m.message.conversation || m.msg.caption || m.msg.text || (m.mtype == 'listResponseMessage') && m.msg.singleSelectReply.selectedRowId || (m.mtype == 'buttonsResponseMessage') && m.msg.selectedButtonId || (m.mtype == 'viewOnceMessage') && m.msg.caption || m.text
let quoted = m.quoted = m.msg.contextInfo ? m.msg.contextInfo.quotedMessage : null
m.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []
if (m.quoted) {
let type = getContentType(quoted)
m.quoted = m.quoted[type]
if (['productMessage'].includes(type)) {
type = getContentType(m.quoted)
m.quoted = m.quoted[type]
}
if (typeof m.quoted === 'string') m.quoted = {
text: m.quoted
}
m.quoted.mtype = type
m.quoted.id = m.msg.contextInfo.stanzaId
m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat
m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith('BAE5') && m.quoted.id.length === 16 : false
m.quoted.sender = Kyyhst.decodeJid(m.msg.contextInfo.participant)
m.quoted.fromMe = m.quoted.sender === Kyyhst.decodeJid(Kyyhst.user.id)
m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || ''
m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []
m.getQuotedObj = m.getQuotedMessage = async () => {
if (!m.quoted.id) return false
let q = await store.loadMessage(m.chat, m.quoted.id, conn)
 return exports.smsg(conn, q, store)
}
let vM = m.quoted.fakeObj = M.fromObject({
key: {
remoteJid: m.quoted.chat,
fromMe: m.quoted.fromMe,
id: m.quoted.id
},
message: quoted,
...(m.isGroup ? { participant: m.quoted.sender } : {})
})
m.quoted.delete = () => Kyyhst.sendMessage(m.quoted.chat, { delete: vM.key })
m.quoted.copyNForward = (jid, forceForward = false, options = {}) => Kyyhst.copyNForward(jid, vM, forceForward, options)
m.quoted.download = () => Kyyhst.downloadMediaMessage(m.quoted)
}
}
if (m.msg.url) m.download = () => Kyyhst.downloadMediaMessage(m.msg)
m.text = m.msg.text || m.msg.caption || m.message.conversation || m.msg.contentText || m.msg.selectedDisplayText || m.msg.title || ''
m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? Kyyhst.sendMedia(chatId, text, 'file', '', m, { ...options }) : Kyyhst.sendText(chatId, text, m, { ...options })
m.copy = () => exports.smsg(conn, M.fromObject(M.toObject(m)))
m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => Kyyhst.copyNForward(jid, m, forceForward, options)

return m
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
