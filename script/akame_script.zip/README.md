[ HELLO USERS SCRIPT AKAME ]
SAYA SELAKU OWNER YANG MENGEMBANGKAN SCRIPT AKAME DARU VERSI 1 HINGGA KE VERSI SEKIAN SANGAT BERTERIMAKASIH KEPADA USER YABG SETIA KEPADA SCRIPT AKAME

✅ Username : akame
✅ Password : akameai

Note : Akame Tidak Support Panel Node.js 20+ ya dia supoort nodejs 20-

npm instal ( instal nya lama jadi di tinggal aja kalo lagi instal ) 
npm start

//////////////////\\\\\\\\\\\\\\\\\\\\////////////////////

*[ THAKS TO ]*
AllahSwt
LKeluarga
Fallzx ( base ) 
Yann ( Friend ) 
Rerezz ( Friend ) 
Kayy ( Friend ) 
User Script 
Penyedia Api
//////////////////\\\\\\\\\\\\\\\\\\\\////////////////////

[ /> INFO LEBIH LANJUT AKAME <\ ]
My Creator : Kyy
Name Bot : Akame - AI
No Dev : 6288286624778

Script Ini Bersifat Gratis Dan Tidak Di Jual
Jika Ingin Info Update Bisa Join Chanel 
Atau Ke Youtube Janlup Subscribe And Like
> https://www.youtube.com/@KyyXdz

 - Source Script ↓
https://whatsapp.com/channel/0029Vb7gTNO5a2450z5MnD0k3G
//////////////////\\\\\\\\\\\\\\\\\\\\////////////////////

( Warning ⚠ )
Saya Telah Menengaskan Untuk Tidak Menjual Script Akame Dan Jika Kalian Ingin Merecode Alangkah Baik Nya Credit Tidak Di Hapus Setelaha Itu Jika Kalian Ingin Post Ke Sosmed Script Jangan Lupa Tag Youtube Di Atas 
Jika Ada Yang Meluhat Menjual Segera Lapor
Hadia Saksi : - Ke WhatsApp Saja